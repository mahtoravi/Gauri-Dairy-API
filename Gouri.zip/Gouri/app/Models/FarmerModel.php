<?php 
namespace App\Models;
use CodeIgniter\Model;

class FarmerModel extends Model
{
    protected $table = 'farmer';

    protected $primaryKey = 'f_id ';

    protected $allowedFields = ['f_id',	'farmer_id',	'farmer_name',	'farmer_email',	'farmer_phone',	'farmer_website',	'farmer_owner',	'farmer_produce','farmer_bussiness_type',	'farmer_certifier',	'farmer_status',	'created_at',	'updated_at',	'added_by'];

    public function getEditdata($id)
    {
        return $this->db->table('farmer as f')
        ->where('f.f_id',$id)
        ->where('f.farmer_status','0')
        ->join('farmer_address fa','fa.f_id=f.f_id','left')
        ->get()->getRow();
        
    }
    public function farmer_list()
    {
        return $this->db->table('farmer as f')
        ->where('f.farmer_status','0')
        ->join('farmer_address fa','fa.f_id=f.f_id','inner')
        ->orderBy('f.f_id','DESC')
        ->get()->getResultArray();
    }
    public function top_farmer()
    {
        return $this->db->table('farmer as f')
        ->where('f.farmer_status','0')
        ->join('farmer_address fa','fa.f_id=f.f_id','inner')
        ->limit(10)
        ->orderBy('f.f_id','DESC')
        ->get()->getResultArray();
    }
}