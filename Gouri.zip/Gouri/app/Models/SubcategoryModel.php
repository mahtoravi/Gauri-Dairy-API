<?php 
namespace App\Models;
use CodeIgniter\Model;

class SubcategoryModel extends Model
{
    protected $table = 'subcategory';

    protected $primaryKey = 'subcategory_id ';
    
    protected $allowedFields = ['category_id','subcategory_name', 'added_by','subcategory_status','updated_at','created_at'];
}