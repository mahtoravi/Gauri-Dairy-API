<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $title ?></title>

    <!-- Favicon -->
    <link rel="icon" type="image/png" href="<?php echo base_url() ?>/assets/dist/img/fresh.jpg">
</head>

<body class="hold-transition login-page">
    <div class="login-box">
        <div class="login-logo">
            <a href=""><b>Forget  &nbsp;&nbsp; </b>Password</a>
        </div>
        <!-- /.login-logo -->
        <div class="card">
            <div class="card-body login-card-body">
                <p class="login-box-msg">Verify Email</p>

                <form action="<?= base_url() ?>" method="post">
                <br/>
                    <div class="input-group mb-3">
                        <input type="email" class="form-control" placeholder="Email">
                        <div class="input-group-append">
                            <div class="input-group-text">
                                <span class="fas fa-envelope"></span>
                            </div>
                        </div>
                    </div>
                    <br/>
                    <div class="row">
                        <!-- /.col -->
                    
                            <button type="submit" class="btn btn-success btn-block">Verify</button>
                        </div>
                        <!-- /.col -->
                    </div>
                </form>


                <div class="social-auth-links text-center mb-3">
          
          <a href="#">
            <i class="fab fa-key mr-2"></i> Back To Login 
          </a>
            </div>

        </div>
    </div>
    <!-- /.login-box -->

</body>

</html>