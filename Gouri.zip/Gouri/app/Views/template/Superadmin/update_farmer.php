<!-- Content Header (Page header) -->
<?php
$session = session();
?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">


                <?php if ($session->getFlashdata('msgS')) { ?>
                    <div class="alert alert-success alert-dismissible">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong>
                            <?= $session->getFlashdata('msgS'); ?>
                        </strong>
                    </div>

                <?php } ?>
                <?php if ($session->getFlashdata('msgE')) { ?>
                    <div class="alert alert-danger alert-dismissible ">
                        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
                        <strong> <?= $session->getFlashdata('msgE'); ?></strong>
                    </div>
                <?php } ?>

            </div>
           
        </div>
        <div class="pull-right">
            <a href="#" class="btn btn-success"><i class="fa fa-edit"></i>
            Update Farmer Details
            </a>
        </div>
    </div><!-- /.container-fluid -->

</section>
<!-- Message -->

<div class="form-group">
                            </div>
                    <div class="row">
                    <div class="form-group col-md-3 mb-2">
                    </div>
                   
                                <div class="form-group col-md-4 mb-2">
                                <label >Select Farmer </label>
                    <select class="form-control select2 select2-danger" id="farmer_id" name="farmer_id" data-dropdown-css-class="select2-danger" style="width: 100%;">
                                        <option value="" readonly> &nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;Select Farmer </option>
                                        <?php
                                        foreach ($farmerList as $key => $result) {

                                        ?>
                                            <option value="<?= $result['f_id'] ?>">
                                                <?= $result['farmer_name'] ?>
                                            </option>
                                        <?php

                                        }
                                        ?>
                    </select>
                                </div></div>
<section class="content" id="form-proccess">
    <div class="container-fluid">
        <div class="row">
            <!-- left column -->
            <div class="col-md-12">
                <!-- general form elements -->
                <div class="card card-info">
                    <!-- <div class="card-header">
                        <h3 class="card-title">Update Farmer Data</h3>
                    </div> -->
                  
                  

                    <form action="<?= base_url() ?>/update-farmer-data" method="post">
                        <div class="card-body">
                            <div class="form-group">
                            </div>

                            <div class="row">
                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInputName">Name</label>
                                    <input type="text" class="form-control" value="" name="farmerName" id="farmerName" placeholder="Enter Name">
                                </div>
                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInput">Email</label>
                                    <input type="text" class="form-control" value="" name="farmerEmail" id="farmerEmail" placeholder="Enter Email">
                                </div>
                            </div>

                            <div class="row">
                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInputZip">Telephone</label>
                                    <input type="text" class="form-control" value="" name="farmerPhone" id="farmerPhone" placeholder="Enter Telephone">
                                </div>
                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInput">Country</label>
                                    <input type="text" class="form-control" value="" name="farmerCountry" id="farmerCountry" placeholder="Enter Country">
                                </div>

                                <!-- <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInput">Webiste</label>
                                    <input type="text" class="form-control" value="" name="farmerEmail" id="farmerEmail" placeholder="Enter Website('url://')">
                                </div> -->
                            </div>

                            <div class="row">
                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInputAddress">Address</label>
                                    <input type="text" class="form-control" value="" name="farmerAddress" id="farmerAddress" placeholder="Enter Address">
                                </div>
                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInputCity">City</label>
                                    <input type="text" class="form-control"  name="farmerCity" id="farmerCity" placeholder="Enter City">
                                </div>


                            </div>
                            <div class="row">
                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInputState">State</label>
                                    <input type="text" class="form-control" value="<?php if (isset($edit_farmer->farmer_state)) {
                                                                                        echo $edit_farmer->farmer_state;
                                                                                    } ?>" name="farmerState" id="farmerState" placeholder="Enter State">
                                </div>
                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInputZip">Zip</label>
                                    <input type="text" class="form-control" value="" name="farmerZip" id="farmerZip" placeholder="Enter Zip">
                                </div>

                            </div>

                            <div class="row">
                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInput">Webiste</label>
                                    <input type="text" class="form-control" value="" name="farmerWebsite" id="farmerWebsite" placeholder="Enter Website('url://')">
                                </div>

                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInput">Owner</label>
                                    <input type="text" class="form-control" value="" name="farmerOwner" id="farmerOwner" placeholder="Enter Owner Name">
                                </div>
                            </div>
                            <div class="row">
                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInputZip">Produce</label>

                                    <?php
                                    $produce = array(
                                        'Kale', 'Bunching Onions',
                                        'Garlic Scapes', 'Yellow Squash', 'Green Zucchini',
                                        'Peppers', 'Cucumbers', 'Spaghetti Squash',
                                        'Patty Pan Squash', 'Eggplant', 'Potatoes', 'Green Beans', 'Carrots',
                                        'Beets', 'Onions', 'Chard', 'Green Kiwi', 'Italian Chestnuts', 'Figs', 'Blueberries',
                                        'Garlic', 'Organic Clementines', 'Gold Kiwi', 'Dried Figs', 'Organic Kiwi',
                                        'Grapes', 'Hazelnuts', 'Lemons'
                                    );
                                    // Arugula, Baby Bok Choi, Basil, Beans - Green, Beets- Baby, Beets-Bagged, Beets-Bunched,
                                    //  Beets-Chioggia, Beets-Gold, Blueberries, Bok Choi, Cabbage Chinese, Cabbage- Green,
                                    //   Cabbage- Napa, Cabbage- Savoy, Callaloo, Cantaloupe, Cardoon, Chives, Cilantro,
                                    //    Collards, Corn, Cucumbers, Dandelions, Diakon, Dill, Eggplant, Eggplant- Indian, 
                                    //    Eggplant- Japanese, Eggplant- Sicilian, Eggplant- Italian, Endive, Escarole,
                                    //     Fennel, Gailon, Horseradish, Kale, Leeks, Lettuce-Bib,
                                    //  Lettuce-Boston, Lettuce- Green Leaf, Lettuce-Red Leaf, Lettuce- Romaine, Methi, Mustard, Nectarines, 

                                    ?>
                                    <input type="text" class="form-control" value="" name="farmerProduce" id="farmerProduce" placeholder="Enter  Produce">
                                </div>

                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInput">Certifier</label>
                                    <?php $certifier = array('NJDA Organic', 'USDA Organic') ?>
                                    <select class="form-control select2 select2-danger" name="farmerCertifier" id="farmerCertifier" data-dropdown-css-class="select2-danger" style="width: 100%;">
                                        <option value="0" readonly> &nbsp;&nbsp;Select Certifier </option>
                                        <?php
                                        foreach ($certifier as $key => $result) {
                                        ?>
                                          <option value="<?=$result?>"><?=$result?></option>
                                        <?php

                                        }
                                        ?>




                                    </select>
                                    <!-- <input type="text" class="form-control" value="" name="farmerCertifier" id="Certifier" placeholder="Enter Certifier "> -->
                                </div>
                            </div>
                           
                            <div class="row">
                                <div class="form-group col-md-6 mb-2">
                                    <label for="exampleInputZip">Business Type</label>
                                    <?php $type = array('Farms', 'Wholesaler', 'Importer') ?>
                                    <select class="form-control select2 select2-danger" name="bussines_type" id="bussines_type" data-dropdown-css-class="select2-danger" style="width: 100%;">
                                        <option value="0" readonly> &nbsp;&nbsp;Select Bussines Type </option>
                                        <?php
                                        foreach ($type as $key => $value) {
                                        ?>
                                            <option value="<?= $value ?>"><?= $value ?> </option>
                                        <?php
                                        }
                                        ?>
                                        </option>


                                    </select>
                                    <!-- <input type="text" class="form-control" value="" name="farmerProduce" id="farmerProduce" placeholder="Enter  Produce"> -->
                                </div>
                            </div>


                            <input type="hidden" class="form-control farmer_id"  name="farmer_id" id="farmer_id" placeholder="">


                        </div>
                        <!-- /.card-body -->

                        <div class="card-footer ">
                           <center> <button type="submit" class="btn btn-primary"> Update  </button></center>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>

