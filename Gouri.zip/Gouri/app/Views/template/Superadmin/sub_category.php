<!-- Content Header (Page header) -->
<?php 
$session=session();
?>
<section class="content-header">
    <div class="container-fluid">
        <div class="row mb-2">
            <div class="col-sm-6">

      
      <?php if ($session->getFlashdata('msgS')) { ?>
          <div class="alert alert-success alert-dismissible">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong>
               <?= $session->getFlashdata('msgS'); ?>
              </strong>
          </div>

      <?php } ?>
      <?php if ($session->getFlashdata('msgE')) { ?>
          <div class="alert alert-danger alert-dismissible ">
              <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
              <strong> <?= $session->getFlashdata('msgE'); ?></strong>
          </div>
      <?php } ?>
  
            </div>
            <div class="col-sm-6">
                <ol class="breadcrumb float-sm-right">
                    <li class="breadcrumb-item"><a href="#">Home</a></li>
                    <li class="breadcrumb-item active">sucategory Form</li>
                </ol>
            </div>
        </div>
        <div class="pull-right">
            <a href="<?= base_url(); ?>/subcategory-list" class="btn btn-warning"><i class="fa fa-eye"></i>
                Subcategory List
            </a>
        </div>
    </div><!-- /.container-fluid -->

</section>
<!-- Message -->

<section class="content">
    <div class="container-fluid">
        <div class="row">
            <!-- left column -->
            <div class="col-md-6">
                <!-- general form elements -->
                <div class="card card-info">
                    <div class="card-header">
                        <h3 class="card-title">Create New subcategory</h3>
                    </div>
                    <!-- /.card-header -->
                    <!-- form start -->
                    <form action="<?= base_url()?>/insert-subcategory" method="post">
                        <div class="card-body">
                            <div class="form-group">
                            </div>
                
                            <div class="form-group">
                                <label for="exampleInputcategory">Select Category</label>
                                <select class="form-control select2 select2-danger" name="category_id"data-dropdown-css-class="select2-danger" style="width: 100%;">
                                <option selected="selected" value="0" readonly> &nbsp;&nbsp;Select Category </option>
                               <?php 
                                foreach($category as $category_data):
                                   
                                ?>   
                                <option value="<?=$category_data['category_id']?>"
                                    <?php if(isset($subcategory)){
                                            if($subcategory['category_id']==$category_data['category_id'])
                                            {
                                                echo "selected";
                                            }
                                     }?>><?=$category_data['category_name']?></option>
                                <?php endforeach; ?>
                                </select>

                            </div>
                            <div class="form-group">
                                <label for="exampleInputsubcategory">Subcategory </label>
                                <input type="text" class="form-control" value="<?php if (isset($subcategory['subcategory_name'])){echo $subcategory['subcategory_name'];}?>" name="subcategory" id="subcategory" placeholder="">
                            </div>
                            <input type="hidden" class="form-control" value="<?php if (isset($subcategory['subcategory_id'])){echo $subcategory['subcategory_id'];}?>" name="subcategory_id" id="subcategory_id" placeholder="">
                            

                        </div>
                        <!-- /.card-body -->

                        <div class="card-footer">
                            <button type="submit" class="btn btn-primary">Add</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- <script src="<?= base_url() ?>/assets/plugins/jquery/jquery.min.js"></script> -->
<!-- <script  type="text/javascript">
 $(function() {  

    //Initialize Select2 Elements
    $('.select2').select2()

    //Initialize Select2 Elements
    $('.select2bs4').select2({
      theme: 'bootstrap4'
    });
});


</script> -->