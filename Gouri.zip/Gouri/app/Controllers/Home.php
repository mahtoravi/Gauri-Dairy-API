<?php

namespace App\Controllers;

class Home extends BaseController {

    public function index() {

//        echo 'its Goury';
        $data['title'] = 'Super Admin';
        $data['pageName'] = 'dashboard';
        return view('template/start', $data);
    }

    public function register_company() {
        
    }

}
