<?php

namespace App\Controllers;

use App\Models\SuperModel;
use App\Models\CategoryModel;
use App\Models\FarmeraddressModel;
use App\Models\FarmerModel;
use App\Models\SubcategoryModel;
use CodeIgniter\Controller;
use App\Models\ProductModel;

class ProductController extends BaseController
{

    #form addproduct
    public function addproduct_page()
    {
        $category = new CategoryModel();
        $session = session();
        if (!$session->has('admin_id')) {
            return redirect()->to(base_url('super-admin-login'));
        }
        $data['category'] = $category->where('category_status', '0')->findAll();
        $data['title'] = 'Add Product';
        $data['pageName'] = 'add_product';
        echo  view('Superadmin/start', $data);
    }

    //Insert 
    public function insert_product()
    {
        $category = new CategoryModel();
        $product = new ProductModel();
        $session = session();
        if (!$session->has('admin_id')) {
            return redirect()->to(base_url('super-admin-login'));
        }
        $id = $this->request->getVar('product_id');
        if (isset($id) && !empty($id)) {     
            $image = $this->request->getFile('productImage');
            if($image==''){
                echo "Null";
                $data = array(
                    'product_name' => $this->request->getVar('productName'),
                    'product_category' => $this->request->getVar('productCategory'),
                    'product_status' => '0',
                    'updated_at' => date('Y-m-d'),
                    'added_by' => $session->get('admin_id')
    
                );
            }
            else{

            if ($image->isValid()) {
                $file = $image->getClientName();
                $image->move('./public/upload');
                echo "Image";
                //unlink(base_url("./public/upload/".$file));
            }
            $data = array(
                'product_name' => $this->request->getVar('productName'),
                'product_category' => $this->request->getVar('productCategory'),
                'product_image' => $file,
                'product_status' => '0',
                'updated_at' => date('Y-m-d'),
                'added_by' => $session->get('admin_id')

            );
        }
            
            $res = $product->update($id,$data);
            if ($res) {
                $session->setFlashdata('msgS', ' Product Updated Successfully  !!!');
                return redirect()->to(base_url('product-list'));
            } else {
                $session->setFlashdata('msgE', 'Update Failed !!!');
                return redirect()->to(base_url('product-list'));
            }

        } else {


            $image = $this->request->getFile('productImage');
            if ($image->isValid()) {
                $image->move('./public/upload');
            }
            $file = $image->getClientName();
            $data = array(
                'product_name' => $this->request->getVar('productName'),
                'product_category' => $this->request->getVar('productCategory'),
                'product_image' => $file,
                'product_status' => '0',
                'created_at' => date('Y-m-d'),
                'added_by' => $session->get('admin_id')

            );
            $res = $product->insert($data);
            if ($res) {
                $session->setFlashdata('msgS', ' Product added Successfully  !!!');
                return redirect()->to(base_url('product-list'));
            } else {
                $session->setFlashdata('msgE', 'Failed !!!');
                return redirect()->to(base_url('product-list'));
            }
        }
    }


    #edit
    public function edit_product($id = null)
    {
        $session = session();
        if (!$session->has('admin_id')) {
            return redirect()->to(base_url('super-admin-login'));
        }
        $category = new CategoryModel();
        $product=new ProductModel();
        $data['product'] = $product->editProduct($id);
        $data['category'] = $category->where('category_status', '0')->findAll();
        $data['title'] = "Edit Product";
        $data['pageName'] = 'add_product';
        echo view('Superadmin/start', $data);
    }

    //Delete Product
    public function delete_product($id = null)
    {

        $session = session();
        if (!$session->has('admin_id')) {
            return redirect()->to(base_url('super-admin-login'));
        }

        $product = new ProductModel();
        $subcategory = new SubcategoryModel();
        $res = $product->where('p_id', $id)->delete();
        if ($res) {
            $session->setFlashdata('msgS', 'Product Deleted !!!');
            return redirect()->to(base_url('product-list'));
        } else {
            $session->setFlashdata('msgE', 'Delete Failed !!!');
            return redirect()->to(base_url('product-list'));
        }
    }

    public function listOfproduct()
    {
        $category = new CategoryModel();
        $product = new ProductModel();
        $data['product'] = $product->getproduct_detalis();

        $data['title'] = 'Product List';
        $data['pageName'] = 'listOfproduct';
        echo  view('Superadmin/start', $data);
    }



    
}
